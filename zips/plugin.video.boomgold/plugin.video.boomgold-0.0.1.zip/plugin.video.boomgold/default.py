import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,urlresolver

AddonTitle     = "BOOMgold"
addon_id       = 'plugin.video.boomgold'
art            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
addon_fanart   = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
icon           = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
baseurl        = 'http://brettusbuilds.com/Boom!/BOOMgold/HOME/goldhome.xml'

def INDEX():
        url=baseurl
        link=open_url(url)
        match= re.compile('<item>(.+?)</item>').findall(link)
        for item in match:
            try:
                if '<folder>'in item:
                                data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
                                for name,url,iconimage,fanart in data:
                                        addDir(name,url,2,iconimage,fanart)
                else:
                                links=re.compile('<link>(.+?)</link>').findall(item)
                                if len(links)==1:
                                        data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
                                        lcount=len(match)
                                        for name,url,iconimage,fanart in data:
                                                addLink(name,url,4,iconimage,fanart)
                                elif len(links)>1:
                                        name=re.compile('<title>(.+?)</title>').findall(item)[0]
                                        iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
                                        fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
                                        addLink(name,url2,7,iconimage,fanart)
            except:pass
        addDir('[B][COLOR white]SEARCH[/COLOR][/B]',url,6,art+'search.png',addon_fanart)
    
def GETPLAYLIST(name,url,iconimage,fanart):
        link=open_url(url)
        match= re.compile('<item>(.+?)</item>').findall(link)
        count=len(match)
        for item in match:
            try:
                if '<folder>'in item: FOLDER(item)
                else:GETPLAYLISTCONTENT(item,url)
            except:pass
            

def GETPLAYLISTCONTENT(item,url):
        links=re.compile('<link>(.+?)</link>').findall(item)
        data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
        if len(links)==1:
                data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
                for name,url,iconimage,fanart in data:
                        addLink(name,url,4,iconimage,fanart)
        elif len(links)>1:
                name=re.compile('<title>(.+?)</title>').findall(item)[0]
                iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
                fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
                addLink(name,url,7,iconimage,fanart)

def FOLDER(item):
        data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
        for name,url,iconimage,fanart in data:
                addDir(name,url,2,iconimage,fanart)

def CHECKLINKS(name,url,iconimage):
        try:
                if urlresolver.HostedMediaFile(url).valid_url():
                        url = urlresolver.HostedMediaFile(url).resolve()
                        PLAYLINKS(name,url,iconimage)
        except:
                notification(addtags('[COLOR red]BOOM[/COLOR][COLOR gold]gold[/COLOR]'),'Stream Unavailable', '3000', icon)


def PLAYLINKS(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def SEARCH():
	keyb = xbmc.Keyboard('', '[COLOR white]SEARCH[/COLOR] - [COLOR red]BOOM[/COLOR][COLOR gold]gold[/COLOR]')
	keyb.doModal()
	if (keyb.isConfirmed()):
		searchterm=keyb.getText()
		searchterm=searchterm.upper()
	else:quit()
	link=open_url('http://brettusbuilds.com/Boom!/BOOMgold/SEARCH/goldsearch.xml')
	slist=re.compile('<link>(.+?)</link>').findall(link)
	for url in slist:
                try:
                        link=open_url(url)
                        entries= re.compile('<item>(.+?)</item>').findall(link)
                        for item in entries:
                                match=re.compile('<title>(.+?)</title>').findall(item)
                                for title in match:
                                        title=title.upper()
                                        if searchterm in title:
                                            try:
                                                if '<folder>'in item: GETPLAYLISTCONTENT(name,url,iconimage,fanart,item)
                                                else:GETPLAYLISTCONTENT(name,url,iconimage,fanart,item)
                                            except:pass
                except:pass

def GETMULTI(name,url,iconimage):
    streamurl=[]
    streamname=[]
    streamicon=[]
    link=open_url(url)
    urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
    iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
    links=[]
    if '<link>' in urls:
                nlinks=re.compile('<link>(.+?)</link>').findall(urls)
                for nlink in nlinks:
                        links.append(nlink)
    i=1
    for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                else:
                        domain=sturl.split('/')[2].replace('www.','')                        
                        streamurl.append( sturl )
                        streamname.append('Link '+str(i)+ ' | ' +domain)
                i=i+1
    dialog = xbmcgui.Dialog()
    select = dialog.select(name,streamname)
    if select < 0:quit()
    else:
        url = streamurl[select]
        CHECKLINKS(name,url,iconimage)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       

def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    link=link.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>')
    return link  

def addItem(name,url,mode,iconimage,fanart,description=''):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
    liz.setProperty('fanart_image', fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def addDir(name,url,mode,iconimage,fanart):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None; fanart=None; description=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
try: description=urllib.unquote_plus(["description"])
except: pass

if mode==None or url==None or len(url)<1:INDEX()
elif mode==2: GETPLAYLIST(name,url,iconimage,fanart)
elif mode==3: GETPLAYLISTCONTENT(name,url,iconimage,fanart)
elif mode==4: CHECKLINKS(name,url,iconimage)
elif mode==5: PLAYLINKS(name,url,iconimage)
elif mode==6: SEARCH()
elif mode==7: GETMULTI(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

