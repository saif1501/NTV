Forked from Simple Favs, Moved the addon data path to Addons to enable Instant Hub Update. 

If you like what i did to this addon then please fork it. 