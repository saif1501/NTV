# skin.titan

This skin is available in the official Kodi repository.

Installation instructions:
 1. In Kodi, go to Settings --> Appearance --> Skin
 2. Press the "Get more" button
 3. Select Titan and hit install
 4. Default installation now complete and you can sit back and enjoy :-)

## Beta version repository
If you want to try out the latest features you can install my beta repository:

 
PLEASE DO NOT INSTALL THE SKIN FROM GITHUB, I WILL NOT PROVIDE SUPPORT !
USE OFFICIAL VERSION FROM KODI REPO OR THE BETA VERSION FROM EMBY REPO ONLY!

Bug reports and feature requests
Feel free to post a message on the forum or send me a PM to get support for the skin, I'll be glad to assist. Also I'm also looking for users with feedback or suggestions about the skin. If you have a feature you would like to see included, please ask on the feature requests thread!

FORUM: http://forum.kodi.tv/forumdisplay.php?fid=212
